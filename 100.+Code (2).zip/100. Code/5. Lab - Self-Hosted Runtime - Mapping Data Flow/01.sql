CREATE TABLE WebLogs
(
    LogDate date,
    IPAddress varchar(20),
    RequestMethod varchar(10),
    RequestResource varchar(1000)
);


